Installation and configuration
==============================

1. Install Menu Banner (menu_banner) module as usual.
2. Go to configuration page at "admin/config/user-interface/menu-banner".
3. Add default menu banner.
4. Edit any menu link and add banner to it.
